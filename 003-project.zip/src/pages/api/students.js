const Handler = (req, res) => {
  const students = ["sana", "arman", "shayan", "reza"];
  res.json(students);
};

export default Handler;
