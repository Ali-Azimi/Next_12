import Head from "next/head";

const AboutPage = () => {
  return (
    <>
      <Head>
        <title>About Us</title>
        <meta name="description" content="this page for foaln ..." />
      </Head>
      <h1>ABOUT</h1>
    </>
  );
};

export default AboutPage;
