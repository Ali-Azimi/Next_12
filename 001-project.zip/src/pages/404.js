const NotFound = () => {
  return <h1>MY CUSTOM NOT FOUND PAGE</h1>;
};

export default NotFound;
