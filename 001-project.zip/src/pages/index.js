const HomePage = () => {
  return (
    <>
      <h1>HOMEPAGE</h1>
      <p>Welcome to Next Course</p>
    </>
  );
};

export default HomePage;
