


const Custom404 = () => {
    return <h1>CUSTOM 404</h1>
}

export default Custom404