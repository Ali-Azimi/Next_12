



const Layout = ({children}) => {
    return (
        <>
        <h1>CONTACT LAYOUT</h1>
        {children}
        </>
    )
}


export default Layout;