


const Loading = () => {
    return <h1>LOADING...</h1>
}

export default Loading;