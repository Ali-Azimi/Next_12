'use client';

const Harchi = () => {
    return <h1>KHATA KHORDIM...</h1>
} 


export default Harchi;